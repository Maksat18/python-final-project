from django import forms


#Suleyman
class EntryForm(forms.Form):
    """Class for Entry form for entering carpets """
    title = forms.CharField(label='', widget=forms.TextInput(attrs={
        "class": "carpet_name",
        "placeholder": "Carpet Name"
    }))

    size = forms.IntegerField()
    
    price = forms.IntegerField()

    



