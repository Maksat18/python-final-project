from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _


# Create your models here.
class User(AbstractUser):
    def __str__(self) -> str:
        return f"{self.username}"

#Maksat
class Carpet(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_id")
    carpet_name = models.CharField(max_length=64)
    description = models.TextField()
    price = models.IntegerField()
    width = models.IntegerField()
    height = models.IntegerField()

    class Status(models.TextChoices):
        INSTOCK = 'INSTOCK', _('In-stock')
        SOLD = 'SOLD', _('Sold')
        RETURNED = 'RETURNED', _('Returned')

    status = models.CharField(
        max_length=10,
        choices=Status.choices,
        default=Status.INSTOCK,
    )

    image = models.ImageField(null=True, blank=True)

    def __str__(self):
        return f"{self.user}: {self.carpet_name}"
