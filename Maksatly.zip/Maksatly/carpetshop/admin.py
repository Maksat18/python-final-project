from django.contrib import admin
from . models import User, Carpet

# Register your models here.

class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'username','first_name','last_name', 'email')


class CarpetAdmin(admin.ModelAdmin):
    list_display = ('id', 'carpet_name','description','price','status','width','height')


admin.site.register(User, UserAdmin)
admin.site.register(Carpet, CarpetAdmin)